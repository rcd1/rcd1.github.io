import time
import threading
import tkinter as tk
from pynput.mouse import Controller, Button
from pynput.keyboard import Listener, KeyCode

SLEEP_TIME = 0.001
TOGGLE_KEY = KeyCode(char="t")

clicking = False
mouse = Controller()

def clicker():
    while True:
        if clicking:
            mouse.click(Button.left, 1)
        time.sleep(SLEEP_TIME)

def start_clicking():
    global clicking
    clicking = True
    status_label.config(text="Clicking...")

def stop_clicking():
    global clicking
    clicking = False
    status_label.config(text="Stopped")

def on_close():
    global clicking
    clicking = False
    root.destroy()

def toggle_event(key):
    if key == TOGGLE_KEY:
        global clicking
        clicking = not clicking
        status_label.config(text="Clicking..." if clicking else "Stopped")
        status_label.config(fg="lime" if clicking else "red")

def set_sleep_time():
    global SLEEP_TIME
    try:
        # Get input from entry and convert to float
        SLEEP_TIME = float(sleep_time_entry.get())
        status_label.config(text=f"Set interval to {SLEEP_TIME} seconds", fg="yellow")
    except ValueError:
        # Handle invalid input
        status_label.config(text="Invalid interval input", fg="red")

# GUI setup
root = tk.Tk()
root.title("Autoclicker")

# Set window size
window_width = 400
window_height = 300
root.geometry(f"{window_width}x{window_height}")

# Setting dark mode colors
bg_color = "#2e2e2e"  # Dark background
fg_color = "#ffffff"  # White text
btn_bg_color = "#444444"  # Darker button background
btn_fg_color = "#ffffff"  # White text on buttons
root.configure(bg=bg_color)

# Input for setting SLEEP_TIME
sleep_time_label = tk.Label(root, text="Set Click Interval (seconds):", bg=bg_color, fg=fg_color, font=("Arial", 12))
sleep_time_label.pack(pady=10)

sleep_time_entry = tk.Entry(root, bg=btn_bg_color, fg=fg_color, width=15)
sleep_time_entry.pack(pady=5)

set_button = tk.Button(root, text="Set Interval", command=set_sleep_time, bg=btn_bg_color, fg=btn_fg_color, width=20, height=2)
set_button.pack(pady=10)

status_label = tk.Label(root, text="Stopped", bg=bg_color, fg=fg_color)
status_label.pack(pady=10)

keybind_label = tk.Label(root, text="Press 't' to toggle clicking", bg=bg_color, fg=fg_color)
keybind_label.pack(pady=10)

root.protocol("WM_DELETE_WINDOW", on_close)

# Start the clicker thread
click_thread = threading.Thread(target=clicker)
click_thread.daemon = True
click_thread.start()

# Start the keyboard listener
listener = Listener(on_press=toggle_event)
listener.start()

root.mainloop()
